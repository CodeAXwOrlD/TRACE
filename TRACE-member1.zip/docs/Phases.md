# Phases: TRACE build plan

Do one phase at a time. A phase is done only when every checkbox under "Done when" is true. Update `Memory.md` at the end of each phase.

---
## Phase 0: Setup and dataset audit
**Goal:** know exactly what is in the data and confirm every VERIFY item.
- Create the repo structure from Architecture.md, `.env.example`, `.gitignore` (ignore `data/`, `.env`).
- Read the dataset `README.md`. Fill the open questions in PRD.md section 12: judging rubric, policies R1..Rn, action names, `case_pack.csv` format, `card_id` derivation, device keying.
- `etl/profile_data.py`: row counts, null rates for the columns TRACE needs, class balance of `closed_cases_history`, distribution of `risk_score` vs outcome.

**Done when**
- [ ] Repo runs (`npm run dev`, `uvicorn`) with hello-world pages.
- [ ] PRD.md open questions are answered and the VERIFY notes updated.
- [ ] A data profile report exists and is summarised in `Memory.md`.

---
## Phase 1: Data pipeline and graph load
**Goal:** the data is in TigerGraph, queryable.
- Polars lazy scan of `transactions.csv`, select needed columns, write Parquet.
- Join identity on `TransactionID`.
- Build vertex and edge tables. Create the TigerGraph schema. Load in batches.
- Load `closed_cases_history.csv` as `ClosedCase` plus its edges.

**Done when**
- [ ] Peak RAM during ETL stays well under the 16 GB limit.
- [ ] Vertex and edge counts in TigerGraph match the source row counts.
- [ ] A test query returns a card's transactions in time order using `NEXT` edges.

---
## Phase 2: Graph queries and evidence primitives
**Goal:** reusable, bounded queries the agent will call.
- `look_back_forward(card, txn, window)`
- `connected_cards_via_device(device)` and via other shared entities
- `closed_cases_for(card | device | connected cards)`
- `card_baseline(card)` (typical amount, channel mix, regions, activity rate)
- `subgraph_for_case(case_id, max_nodes=200)`

**Done when**
- [ ] Each query has a test and returns within a few seconds.
- [ ] Queries are hop- and size-bounded.

---
## Phase 3: Pattern detectors
**Goal:** one detector per pattern, plus undocumented.
- `card_testing`, `cnp`, `cnp_new_device`, `out_of_region`, `account_takeover`, `undocumented`.
- Each returns `{matched, confidence, evidence[]}`.
- `undocumented` fires only when coordinated abuse is present and no known pattern matches.
- Validate against `closed_cases_history` (the `pattern` column is the label).

**Done when**
- [ ] Per-pattern precision and recall reported.
- [ ] No detector reads the LLM. All are deterministic and unit-tested.

---
## Phase 4: Scoring, uncertainty and policy
**Goal:** the decision core, no LLM yet.
- Feature builder, log-odds model, prior correction, calibration.
- Uncertainty rules.
- Policy engine driven by `policies.yaml` (real policies from the README).
- Verdict thresholds in config.

**Done when**
- [ ] Calibration plot on held-out closed cases looks sane.
- [ ] A recurring-customer case with a high `risk_score` comes out LEGITIMATE.
- [ ] A conflicting-evidence, high-exposure case comes out UNCERTAIN with an escalate action.

---
## Phase 5: Agent (LangGraph) and case memory
**Goal:** the full investigation runs end to end.
- Wire the steps from Architecture.md section 2 as a LangGraph.
- Similar-case retrieval.
- LLM writes the rationale from structured evidence only, with a template fallback.
- SSE stream of step events.
- Case write-back (`InvestigationCase` and edges).

**Done when**
- [ ] `POST /api/investigate` returns a valid result for any benchmark case.
- [ ] The stream emits one event per step.
- [ ] Turning the LLM off does not change verdict, probability or actions.

---
## Phase 6: Benchmark evaluation
**Goal:** measure and tune on the 20 cases.
- `tests/test_benchmark.py` runs all 20 and prints verdict, pattern and action vs expected (where the pack provides them).
- Tune thresholds and weights in config, not in code.
- Fix the worst failures by category.

**Done when**
- [ ] Scoreboard exists and is reproducible.
- [ ] Any remaining misses are understood and listed in `Memory.md`.

---
## Phase 7: Frontend foundation and landing
**Goal:** the cinematic entry.
- Design tokens, fonts, layout shell, nav.
- `NeonText` component (SVG glyph-border light, canvas-traced edges, stars, sparkles), ported from `reference/trace-cinematic-v2.html`.
- `IntroSequence`: outline, light hops letter to letter, ignite, tagline, outro push-through, skip button, reduced-motion path.
- Hero with the 3D-tilted graph illustration and floating cards.

**Done when**
- [ ] Intro plays once, is skippable, and hands off to the hero cleanly.
- [ ] Reduced-motion users see the final state immediately.
- [ ] Section headings ignite on scroll.

---
## Phase 8: Workbench UI
**Goal:** the analyst experience, wired to the API.
- Case queue, verdict panel with risk score vs probability, uncertainty band.
- **Evidence to Decision chain** animating from the SSE stream.
- Card timeline showing where the episode began.
- Connected-records graph (Sigma.js, at most 200 nodes).
- Three outcome states designed with equal care.
- "Add evidence" action that re-scores and updates the chain.

**Done when**
- [ ] All 20 cases open and render without errors.
- [ ] The chain visibly updates when evidence is added.
- [ ] Loading, empty and error states exist for every panel.

---
## Phase 9: Polish, deploy, demo
- Performance pass on the laptop (no jank in the graph or intro).
- Accessibility pass: labels, focus states, contrast, reduced motion.
- Deploy frontend and backend. Smoke test against the hosted TigerGraph.
- Demo script covering one FRAUD, one LEGITIMATE and one UNCERTAIN case, and one "flagged transaction is not the origin" case.

**Done when**
- [ ] A fresh browser opens the hosted app and the demo runs start to finish.
- [ ] README explains setup and how to run the benchmark.
