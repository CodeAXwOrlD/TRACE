# Design: TRACE

Approved previews are in `reference/`. Match them. When this file and a preview disagree, ask.

## 1. Direction
Dark, cinematic, investigative. A film-title feel on the landing page, a calm evidence-first workbench inside. Never a red-alert "FRAUD DETECTED" look: all three outcomes are treated as credible.

## 2. Colour tokens
```css
:root{
  --bg:#050608;            --panel:#0a0e13;      --panel-soft:#0d1218;
  --white:#f4f6f8;         --muted:#8894a0;      --dim:#56616c;
  --orange:#ec6408;        --orange-soft:#ff9a52;
  --blue:#3e9bd0;
  --green:#3bd29d;         /* legitimate */
  --red:#ff4b42;           /* fraud */
  --amber:#feba12;         /* uncertain */
  --border:rgba(255,255,255,.09);
}
```
- Orange is the brand accent (second headline line, primary buttons, active steps).
- Blue is the "connection/graph" accent.
- Verdict colours: red = FRAUD, green = LEGITIMATE, amber = UNCERTAIN. Use them for pills, the verdict word and a thin top or left accent line. Do not flood whole panels with them.
- Backgrounds: near-black with two faint radial glows (blue top right, orange left), a very faint 80px grid, and a soft vignette.

## 3. Typography
- **Inter** (400, 500, 600, 700, 800): all UI and headlines.
- **JetBrains Mono** (400, 500, 600): labels, IDs, actions, numbers in panels.
- Headlines: weight 800, letter-spacing about -0.045em to -0.05em, tight line-height (about 1.05).
- Section labels: mono, 11px, letter-spacing 0.14em, blue.
- Body: 15 to 16px, line-height 1.7, colour `--muted`; emphasised words `#cfd6dc`.
- Fallback stacks: `system-ui, -apple-system, "Segoe UI", Roboto, sans-serif` and `ui-monospace, Menlo, Consolas, monospace`.

## 4. Signature effect: neon border light on text
Real text is rendered as SVG. Glyph edges are traced from a canvas render of the same font. A light window travels along the **outline** of the letters, hopping from character to character:
- Border glows with a comet tail behind the head (asymmetric gradient stroke).
- A 4-point star rides the **top** edge; a second, smaller star rides the **bottom** edge slightly behind.
- Small sparkles pop on the border behind the head (about 9 per line, life 0.45 to 0.85 s).
- The letter fill ignites under the light and settles after it passes. Fill reveals in as the light passes on first play.
- Speed about 3.6 x font-size units per second inside a character, faster between characters. Lines overlap by about 45%.
- Tones: `ice` (white text, cyan-blue light) and `fire` (orange text, amber light).
- Replays: hero headline gets one slow glint every 12 s. Section headings play once when scrolled into view.
- Accessibility: the heading keeps `aria-label` with the real text. Animated SVG is `aria-hidden`.
- Reference implementation: `reference/trace-cinematic-v2.html`, class `Neon`.

## 5. Intro and outro (first load)
1. Black screen. TRACE wordmark outline fades in as unlit steel tubes (about 1.2 s).
2. Cool light with stars hops T, R, A, C, E (slow), fill reveals dark glass.
3. **Ignite:** border turns warm orange neon, warm glow fades in, a horizontal flare sweeps across the screen, a fast second pass runs.
4. Tagline "AGENTIC FRAUD INVESTIGATION" fades in (mono, wide tracking).
5. **Outro:** wordmark pushes toward the camera (scale to about 1.75, blur, fade), overlay dissolves, the site rises in.
6. Total about 8 s. **Skip intro** button (bottom right) and Escape must work at any time.
7. `prefers-reduced-motion`: no intro, final state shown immediately.

## 6. Motion rules
- Page entrance: elements rise 22px with fade, staggered 0.1 to 0.2 s.
- Scroll reveals: fade and rise 26px, one time only.
- Hero graph: gentle float (8 s), pointer-based tilt (about 9 to 14 degrees), pulse rings on the flagged transaction, particles travelling along edges.
- Evidence chain: steps light up as the user scrolls or as SSE events arrive; the estimate number tweens over about 0.7 s.
- Never more than one attention-grabbing loop on screen at a time.
- Keep blur and glow filters few and static where possible (GPU-conscious).

## 7. Components

**Verdict panel.** Large verdict word in the verdict colour, one-sentence reason, then two bars: Risk score (grey) and Fraud probability (verdict colour) with a shaded uncertainty band. Caption: "Score is one input. Probability comes from the evidence."

**Evidence to Decision chain.** Vertical rail with dots. Each step: small muted title, a semibold value line, a muted detail line, and a tag: Raises concern (red), Lowers concern (green) or Context (none). Final steps are visually heavier: Probability, Uncertainty, Policy, Next best action (action chips in mono).

**Action chips.** Mono 11px, 1px border. First chip filled white with dark text; the rest outlined.

**Connected-records graph.** Node shapes: card = rounded rectangle, customer = circle, transaction = dot (flagged = large orange with pulse), device = diamond, other cards = small rectangles, closed cases = squares (red = confirmed fraud, green = cleared). Edge labels in tiny mono. Cap at about 200 nodes.

**Timeline.** Horizontal points on a thin line. Normal = grey, suspicious = red, flagged = blue and larger. Labels "Fraud began here" and "Flagged" under the relevant points.

**Cards and panels.** Radius 12 to 14px, 1px border `rgba(255,255,255,.08)`, faint fill `rgba(255,255,255,.015)`, a 1 to 2px accent line on one edge, cursor spotlight on hover for outcome cards.

**Buttons.** Primary: orange fill, white text, lifts 2px on hover with a soft orange shadow. Ghost: transparent with a 1px border. Nav button: orange outline that fills on hover.

## 8. Layout
- Max content width 1240px for content sections, hero up to 1500px.
- Hero: two columns (copy left, 3D graph right); single column under 1100px.
- Workbench: three columns (case queue 250px, evidence chain, graph plus timeline); collapses to one column under 1100px.
- Section padding: 150px vertical on desktop, 100px on mobile.

## 9. The three outcome states (copy tone)
- **Fraud, "Confirmed pattern":** "Shared device, connected fraud cases and a customer denial." Actions: BLOCK_CARD, FILE_REPORT, MONITOR_CONNECTED_CARDS.
- **Legitimate, "Low concern":** "Recurring behaviour on a known device. Similar past cases were cleared." Action: CLOSE_NO_FRAUD.
- **Uncertain, "Evidence incomplete":** "The evidence conflicts and exposure is $842, so a person decides." Action: ESCALATE_TO_ANALYST.

Action names above are from the project notes. **VERIFY** against the dataset README.
