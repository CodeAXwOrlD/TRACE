# Member 1 handoff: frontend

Status: **Frontend fully configured, compiled, verified, and test-complete against mock data** (Phases.md Phase 7 + Phase 8 workbench UI).
All unit tests, typechecks, ESLint checks, and production builds succeed with zero errors. Run locally via:

```bash
cd frontend && npm install && npm run dev
```

To run the full test and verification suite:
```bash
npm run typecheck && npm run lint && npm run test && npm run build
```

## What's implemented

- **Landing page** (`app/page.tsx`): full port of `reference/trace-cinematic-v2.html` —
  intro/ignite/outro sequence, the neon glyph-border-light engine, hero with
  pointer-tilted graph illustration, scroll-driven "evidence to decision"
  section, score-vs-probability comparison, outcomes, patterns, final CTA.
  Respects `prefers-reduced-motion` (skips the intro, shows final state).
  Skip button + Escape both work at any point in the intro.
- **Console shell** (`components/console/ConsoleShell.tsx`): top nav, system
  status, ⌘/Ctrl+K command palette, wraps every route under `app/(console)/`.
- **Dashboard**: stats, recent investigations, risk distribution, case/graph/agent activity panels.
- **Investigation workspace** (`app/(console)/investigations/[id]/page.tsx` →
  `components/workbench/InvestigationWorkspace.tsx`): the most important
  screen. Split layout — context / graph / evidence, timeline below.
  Wired to `useInvestigationStream()` for live agent activity.
- **Connected-records graph** (`components/graph/InvestigationGraph.tsx`):
  Sigma.js + Graphology, WebGL, capped to whatever `getInvestigationGraph()`
  returns (mock caps well under 200 nodes). Click a node → detail panel.
  Node *color* is type-coded (customer, card, transaction, device, case).
- **Cases, transactions, customers, devices, settings** pages: fully functional,
  reading through `lib/api.ts`.
- **Mock data / API / SSE**: `mock/*.ts` (including `mock/devices.ts`), `lib/api.ts`, `lib/sse.ts`,
  `hooks/useInvestigationStream.ts`. This is the contract layer.
- **Tests**: `__tests__/*.test.tsx` for RiskScore, EvidenceCard,
  AgentActivity, GraphToolbar (vitest + Testing Library) — all 5 tests passing cleanly.

## Known gaps / left for later (Member 1 scope)

- Custom Sigma node shapes: Node shapes are currently color- and size-coded per type. A future visual enhancement could add custom WebGL node shaders/programs for rounded-rect, diamond, and square shapes.
- Route-level `loading.tsx` / `error.tsx` boundaries: in-component `LoadingState`, `ErrorState`, and `EmptyState` primitives are already functional. Next.js file-based skeletons can be added when real server latency is introduced by Member 3.

## How to connect (Member 2 — agent/LangGraph/LLM)

You don't touch the frontend directly. Your contract is the SSE event stream
consumed by `hooks/useInvestigationStream.ts` via `lib/sse.ts`:

```
GET /api/investigations/:id/stream
{ "type": "investigation_started" }
{ "type": "evidence_found", "data": {...} }
{ "type": "graph_update", "data": {...} }
{ "type": "risk_update", "data": {...} }
{ "type": "agent_message", "data": {...} }
{ "type": "investigation_complete" }
```
Match `AgentEvent` in `lib/types.ts`. The rationale text you generate should
land in `Investigation.rationale` (same file) — the workspace already
renders it verbatim under "RATIONALE", with no extra frontend logic, per
Rules.md #7 ("the LLM explains, it does not decide").

## How to connect (Member 3 — FastAPI/Polars/TigerGraph)

1. Implement the endpoints in Architecture.md §7. Response shapes must match
   `lib/types.ts` (this is the source of truth the frontend was built
   against — keep `backend/app/schemas.py` in lockstep with it, not the
   other way around, unless you find a mismatch worth flagging).
2. Set `NEXT_PUBLIC_API_URL` and `NEXT_PUBLIC_USE_MOCKS=false` in
   `frontend/.env.local`. Every function in `lib/api.ts` already tries the
   real endpoint first and only falls back to mocks on failure — **no
   frontend code changes required.**
3. The graph endpoint must return `InvestigationGraphData` (nodes/edges)
   already capped (≤ ~200 nodes, Architecture.md §10) — the frontend does
   not do any capping or sampling itself.

## Files to modify freely
- Anything under `mock/` (extend fixtures as the real data shape solidifies)
- `lib/types.ts` (but coordinate — this is the shared contract)
- `.env.example` / `.env.local`

## Files not to modify without discussion
- `components/neon/neon-engine.ts` — tuned to match the approved preview;
  see the warning comment at the top of that file.
- `styles/tokens.css`, `styles/landing.css` — mirror Design.md exactly.
- `lib/api.ts` / `lib/sse.ts` — the integration seam; changing its shape
  means updating every page that imports it.
