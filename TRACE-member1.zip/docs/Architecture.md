# Architecture: TRACE

## 1. Tech stack
| Layer | Choice |
|---|---|
| Frontend | Next.js (App Router) + TypeScript, Tailwind, shadcn/ui, GSAP, Motion, Sigma.js (WebGL graph) |
| Backend | FastAPI (Python 3.11+), Pydantic |
| Data prep | Polars (lazy / streaming), no pandas on the full CSV |
| Agent | LangGraph |
| Graph DB | TigerGraph Cloud (remote, not local) |
| LLM | API-based (no local LLM on the dev laptop) |
| Local storage | SQLite for dev; Postgres if a hosted DB is needed |
| Deploy | Vercel (frontend), Render / Railway / Fly (backend) |

Dev machine: Linux Mint, Ryzen 5 5500U, 16 GB RAM, integrated GPU. Consequences:
- TigerGraph stays remote. Do not run it locally.
- Never load `transactions.csv` (~708 MB) whole into memory. Stream, chunk or use Polars lazy scans.
- Never render more than about 200 nodes in the browser.

## 2. High-level flow
```
Browser (Next.js)
   |  POST /api/investigate {transaction_id}
   v
FastAPI
   |
   v
LangGraph agent
   |  1. load_flagged_txn
   |  2. look_back_forward        -> episode + first suspicious txn
   |  3. expand_connections       -> device, email, region, other cards
   |  4. run_detectors            -> 5 patterns + undocumented
   |  5. retrieve_similar_cases   -> closed-case memory
   |  6. score                    -> probability + uncertainty
   |  7. apply_policy             -> policy id + next actions
   |  8. explain                  -> rationale (LLM, grounded in evidence only)
   v
Structured result (see PRD section 9)  ->  streamed to the UI step by step
   |
   v
Write-back: InvestigationCase vertex + edges in TigerGraph
```
The agent streams each step (Server-Sent Events) so the UI can animate the Evidence to Decision chain as it happens.

## 3. Graph schema
From the dataset README:
```
Customer      -OWNS->            Card
Card          -MADE->            Transaction
Transaction   -FROM_DEVICE->     DeviceProfile
Transaction   -PURCHASER_EMAIL-> EmailDomain
Transaction   -BILLED_IN->       BillingRegion
Transaction   -NEXT->            Transaction
ClosedCase    -INVOLVES->        Transaction
ClosedCase    -ON_CARD->         Card
ClosedCase    -CONNECTED_TO->    Card
```
TRACE extension (written when the agent closes a case):
```
InvestigationCase -INVOLVES->       Transaction
InvestigationCase -ON_CARD->        Card
InvestigationCase -CONNECTED_TO->   Card
InvestigationCase -USES_EVIDENCE->  DeviceProfile
InvestigationCase -MATCHES_PATTERN->FraudPattern
InvestigationCase -SIMILAR_TO->     ClosedCase
```
`FraudPattern` is a small extra vertex set: the five known patterns plus `undocumented`.

GSQL sketch (**VERIFY** key derivation against the README before creating anything):
```
CREATE VERTEX Customer(PRIMARY_ID customer_id STRING)
CREATE VERTEX Card(PRIMARY_ID card_id STRING)
CREATE VERTEX Transaction(PRIMARY_ID txn_id STRING, ts DATETIME, amount DOUBLE, channel STRING, risk_score DOUBLE)
CREATE VERTEX DeviceProfile(PRIMARY_ID device_key STRING, device_type STRING, device_info STRING)
CREATE VERTEX EmailDomain(PRIMARY_ID domain STRING)
CREATE VERTEX BillingRegion(PRIMARY_ID region STRING)
CREATE VERTEX ClosedCase(PRIMARY_ID case_id STRING, outcome STRING, pattern STRING, exposure_usd DOUBLE)
CREATE VERTEX InvestigationCase(PRIMARY_ID case_id STRING, verdict STRING, probability DOUBLE)
CREATE VERTEX FraudPattern(PRIMARY_ID name STRING)
```
Only load the transaction columns TRACE actually uses (amount, timestamp, channel, risk_score, card, email domain, billing region, plus the handful of identity fields). Do not load all 393 columns into the graph.

## 4. Scoring design
**Inputs:** `risk_score`, burst and small-charge features, look-back result, device link (number of other cards on the device, and whether any had confirmed fraud), fit against card history, billing region novelty, connected-card outcomes, similar-case outcomes, identity anomalies (new device and so on).

**Method (start simple, upgrade only if time allows):**
1. Evidence features become a weighted log-odds sum (logistic form). Weights are fitted on `closed_cases_history` (fraud vs cleared).
2. **Prior correction:** history is about 84% fraud, the benchmark about 50% legitimate. Shift the intercept so probabilities are meaningful on the benchmark, not just on history.
3. Calibrate (Platt or isotonic) on a held-out slice of closed cases.
4. `risk_score` enters as one feature with a modest weight. It is never returned as the probability.

**Uncertainty (LOW / MEDIUM / HIGH):** derived from
- distance of the probability from 0.5,
- conflict between evidence groups (concern vs ease),
- missing evidence (for example no device record for card-present transactions),
- disagreement among similar historical cases.

**Verdict:** FRAUD above a high threshold with LOW or MEDIUM uncertainty; LEGITIMATE below a low threshold with LOW or MEDIUM uncertainty; otherwise UNCERTAIN. Thresholds are tuned on the closed cases and the 20 benchmark cases, and live in config, not in code.

## 5. Policy engine
`backend/app/policy/policies.yaml` maps conditions to a policy id and actions, for example:
```
R6: shared device with confirmed cases        -> BLOCK_CARD, FILE_REPORT, MONITOR_CONNECTED_CARDS
R2: recurring behaviour on a known device     -> CLOSE_NO_FRAUD
R9: conflicting evidence and exposure > $500  -> ESCALATE_TO_ANALYST
```
Only R6 is confirmed by the project notes. **Replace all of these with the real policy list from the dataset README.** The engine must be data-driven so policies can be edited without touching code.

## 6. Case memory (retrieval)
Similarity between the current case and each closed case combines: pattern, device overlap, connected-card overlap, transaction behaviour features, exposure band. Return the top-k with outcome and analyst notes. Use them as evidence and as a sanity check on the verdict. Graph traversal (shared device or shared connected cards) is the primary retrieval path; vector or text similarity over `analyst_notes` is optional.

## 7. API
| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | liveness |
| GET | `/api/cases` | list the 20 benchmark cases with status |
| POST | `/api/investigate` | run the agent, returns the result contract |
| GET | `/api/investigate/stream?transaction_id=` | SSE: one event per agent step |
| POST | `/api/cases/{id}/evidence` | add evidence (for example customer denial), re-score |
| GET | `/api/graph/{case_id}` | capped subgraph for the UI (max 200 nodes) |
| POST | `/api/cases/{id}/close` | write `InvestigationCase` back to the graph |

## 8. Folder structure
```
trace/
  docs/                      # these md files
  frontend/
    app/
      page.tsx               # landing (intro + hero)
      workbench/page.tsx
      case/[id]/page.tsx
    components/
      intro/                 # IntroSequence, skip button
      neon-text/             # NeonText (SVG glyph-border light), port of the reference engine
      workbench/             # CaseQueue, EvidenceChain, VerdictPanel, Timeline, ConnectedGraph
      ui/                    # shadcn components
    lib/
      api.ts                 # typed client
      types.ts               # mirrors the result contract
    styles/tokens.css        # design tokens from Design.md
  backend/
    app/
      main.py
      config.py
      schemas.py             # Pydantic models = result contract
      api/                   # routers
      agent/
        graph.py             # LangGraph wiring
        state.py
        nodes/               # one file per step listed in section 2
      detectors/             # card_testing.py, cnp.py, cnp_new_device.py, out_of_region.py, account_takeover.py, undocumented.py
      scoring/               # features.py, probability.py, uncertainty.py, calibration.py
      policy/                # engine.py, policies.yaml
      memory/                # case_retrieval.py
      graph/                 # tigergraph_client.py, queries/*.gsql
    etl/
      profile_data.py        # dataset audit
      build_tables.py        # Polars lazy transforms
      load_tigergraph.py
    tests/
      test_detectors.py
      test_scoring.py
      test_policy.py
      test_benchmark.py      # runs the 20 cases
  data/                      # gitignored; the CSVs live here
  reference/                 # approved HTML design previews
  Memory.md
```

## 9. Environment variables
```
TG_HOST=            TG_GRAPH=        TG_SECRET=  (or TG_USERNAME / TG_PASSWORD)
LLM_API_KEY=        LLM_MODEL=
DATA_DIR=./data
FRONTEND_ORIGIN=http://localhost:3000
```
Never commit `.env`. Provide `.env.example` with empty values.

## 10. Performance notes
- ETL: `pl.scan_csv(...)` with column selection, then write Parquet once. Everything downstream reads Parquet.
- Graph queries are per-case and bounded (hop limit, per-card transaction window).
- The UI receives a capped subgraph, never raw tables.
