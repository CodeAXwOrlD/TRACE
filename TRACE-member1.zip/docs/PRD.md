# PRD: TRACE

## 1. Summary
TRACE is an agentic fraud-investigation workbench for the HHGOA_IEEE hackathon.
Given a flagged transaction it investigates on a graph (TigerGraph), uses closed historical cases as memory, and returns:
- a verdict: **FRAUD**, **LEGITIMATE** or **UNCERTAIN**
- a fraud probability with an uncertainty level
- the matched fraud pattern (or "undocumented")
- the policy applied
- the next best action(s)
- the full evidence chain that led there, visible to the analyst

## 2. Problem
- The provided `risk_score` is only an input. It is wrong in both directions: many transactions above 0.7 are legitimate, and some fraud has a low score. **risk_score is not fraud probability.**
- The flagged transaction is not necessarily where the fraud started, and may not be fraud at all.
- About half of the benchmark cases are legitimate. An agent that blocks everything scores badly.
- Fraud is often coordinated across cards through shared devices, so a single-transaction view misses it.

## 3. Users
- **Primary: fraud analyst.** Opens a case, needs a defensible decision and the reasons behind it.
- **Secondary: hackathon judges.** Run the 20 cases in `case_pack.csv` and judge accuracy of the investigation and the next action.

## 4. Goals
1. Correct verdict and pattern on the benchmark cases.
2. Correct next best action per case.
3. Explainable output: every conclusion links to evidence.
4. Calibrated probability, with honest uncertainty.
5. Use historical cases as retrieval memory (GraphRAG plus case memory).
6. A UI that makes all three outcomes feel equally credible, not one that calls everything fraud.

## 5. Non-goals
- Real-time streaming ingestion.
- Training a large model on the full 590k rows in the browser or on the laptop.
- Rendering the whole graph in the UI. Only the current investigation subgraph (about 50 to 200 nodes).
- User accounts and auth (unless the README requires it). **VERIFY**

## 6. Data (from the dataset README; **VERIFY** every number before relying on it)
| File | Size | Contents |
|---|---|---|
| `transactions.csv` | ~708 MB | 590,742 rows. 393 original Vesta columns plus 4 added: `customer_id`, `ts`, `channel`, `risk_score` |
| `identity.csv` | ~25 MB | 144,432 online identity records, 41 columns (`id_01`..`id_38`, `DeviceType`, `DeviceInfo`). Joins on `TransactionID` |
| `closed_cases_history.csv` | ~2.6 MB | 5,565 cases: 4,665 confirmed fraud, 900 cleared. Doubles as the agent's starting memory |
| `case_pack.csv` | ~3 KB | 20 benchmark cases |

`closed_cases_history` columns: `case_id, customer_id, card_id, opened_at, closed_at, outcome, pattern, first_fraud_txn_id, txn_ids, n_txns, exposure_usd, connected_card_ids, actions_taken, report_filed, analyst_notes`.

Note the class balance mismatch: history is about 84% fraud, the benchmark is about 50% legitimate. Probability must be prior-corrected (see Architecture.md).

## 7. Fraud patterns TRACE must detect
1. **Card testing**: 3+ tiny online authorizations within about an hour, then a larger purchase.
2. **Card-not-present (CNP)**: online, unusual behaviour, a burst of transactions, does not fit card history.
3. **CNP with new device**: as above, and the identity record says the device is new.
4. **Out of region**: card-present activity in a new billing region while normal home activity continues.
5. **Account takeover**: mixed-channel behaviour with identity/device/match anomalies suggesting stolen credentials.
6. **Undocumented**: coordinated abuse that fits none of the above. Never force a case into a known pattern.

## 8. Functional requirements

### P0 (must ship)
- **FR-1 Case intake.** Accept a flagged `transaction_id` (and the 20 benchmark cases) and start an investigation.
- **FR-2 Look-back / look-forward.** From the flagged transaction, walk the same card's previous and next transactions and identify the first suspicious transaction and the whole episode.
- **FR-3 Connected entities.** Follow device profile, email domain, billing region and other cards that share them.
- **FR-4 Pattern detectors** for the five known patterns plus "undocumented".
- **FR-5 Case memory.** Retrieve similar closed cases and compare pattern, behaviour, device, connected cards, exposure and analyst outcome.
- **FR-6 Probability and uncertainty.** Combine risk score with all evidence into a fraud probability and LOW/MEDIUM/HIGH uncertainty.
- **FR-7 Policy engine.** Map verdict, uncertainty, exposure and evidence flags to a policy (for example R6) and next best actions.
- **FR-8 Structured output** matching the contract in section 9.
- **FR-9 Evidence to Decision chain UI** (the signature feature): animated chain from transaction to action, updating as new evidence arrives.
- **FR-10 Three-outcome UI** handling FRAUD, LEGITIMATE and UNCERTAIN with equal care.

### P1
- **FR-11** Card timeline showing the fraud episode and where it began.
- **FR-12** Connected-records graph (Sigma.js, capped node count).
- **FR-13** Case write-back: when a case is closed, create `InvestigationCase` with edges to transactions, cards, evidence, pattern and similar closed cases.
- **FR-14** "Add evidence" interaction that re-runs scoring and visibly updates the chain.
- **FR-15** Landing page with the cinematic intro/outro and neon-border text (see Design.md).

### P2
- **FR-16** Batch run over the 20 benchmark cases with a scoreboard.
- **FR-17** Exportable case report.

## 9. Agent output contract
```json
{
  "case_id": "string",
  "transaction_id": "string",
  "card_id": "string",
  "verdict": "FRAUD | LEGITIMATE | UNCERTAIN",
  "fraud_probability": 0.82,
  "uncertainty": "LOW | MEDIUM | HIGH",
  "pattern": "card_testing | cnp | cnp_new_device | out_of_region | account_takeover | undocumented | none",
  "first_suspicious_txn_id": "string | null",
  "episode_txn_ids": ["string"],
  "connected_card_ids": ["string"],
  "similar_cases": [{"case_id": "CC-0141", "similarity": 0.91, "outcome": "fraud"}],
  "evidence": [{"step": "device_link", "finding": "Device on 3 other cards", "direction": "concern | ease | context", "weight": 0.08}],
  "policy": "R6",
  "next_actions": ["BLOCK_CARD", "FILE_REPORT", "MONITOR_CONNECTED_CARDS"],
  "exposure_usd": 842.0,
  "rationale": "short plain-language explanation"
}
```
Field names and the exact action vocabulary must match the dataset README. **VERIFY**

## 10. Success metrics
- Verdict accuracy on `case_pack.csv` (target: as high as possible, tracked per pattern).
- Next-best-action match rate.
- Pattern match rate, including correct "undocumented" calls.
- Calibration: probability bins line up with observed outcomes on held-out closed cases.
- No case where the agent blocks a clearly legitimate recurring-customer case.

## 11. Judging alignment
- Investigation Accuracy: 25%
- Next Best Action: 25%
- Remaining criteria: **VERIFY in README** (likely explainability, graph use, UI, and originality)

## 12. Open questions (resolve from the dataset README before Phase 2)
1. Full judging rubric and weights.
2. Exact list of policies (R1..Rn) and their conditions.
3. Exact action names and which combinations are allowed.
4. Format of `case_pack.csv` and the required output format.
5. How `card_id` is derived from Vesta columns, and how `DeviceProfile` is keyed.
6. Whether the TigerGraph Cloud instance and credentials are provided.
