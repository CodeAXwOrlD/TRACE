# Rules: boundaries for the AI

Read this before writing any code. If a rule conflicts with a request, say so and ask.

## Product rules (non-negotiable)
1. **`risk_score` is never the fraud probability.** It is one input. Never display or return it under a "probability" label.
2. **Support all three verdicts equally**: FRAUD, LEGITIMATE, UNCERTAIN. Never default to fraud. Never build a UI that only celebrates fraud detection.
3. **The flagged transaction is not necessarily the origin.** Always look back and forward on the same card before concluding.
4. **Do not force a case into a known pattern.** If it fits none of the five, return `undocumented`.
5. **Every conclusion must point to evidence.** No verdict, probability or action without an evidence item behind it.
6. **Do not invent data.** No made-up case IDs, card numbers, policies, action names or column names in real code paths. Sample data is allowed only in clearly labelled demo fixtures.
7. **The LLM explains, it does not decide.** Verdict, probability and actions come from the scoring and policy code. The LLM writes the rationale from the structured evidence only and must not add facts.
8. **Anything marked VERIFY in the docs must be checked against the dataset README** before it is coded against.

## Data rules
- Never load `transactions.csv` fully into memory. Use Polars lazy or streaming reads, select only needed columns, convert to Parquet once.
- Never commit dataset files. `data/` is gitignored.
- Do not push all 393 Vesta columns into the graph. Load only what the agent uses.
- Never send raw dataset rows to the LLM. Send compact structured evidence.

## Stack rules
**Use:** Next.js + TypeScript, Tailwind, shadcn/ui, GSAP, Motion, Sigma.js, FastAPI, Pydantic, Polars, LangGraph, TigerGraph Cloud (via pyTigerGraph or REST), an API-based LLM.

**Avoid:**
- pandas on the full dataset.
- A local LLM, a local TigerGraph server, Docker-only setups that need more than the laptop's 16 GB.
- Three.js scenes or particle systems heavier than what Design.md describes.
- Rendering more than about 200 graph nodes in the browser.
- New dependencies without a reason written in Memory.md.
- `localStorage`-based app state for case data. Cases come from the API.

## Code rules
- TypeScript strict mode. No `any` unless commented why.
- Python: type hints everywhere, Pydantic models for all API input and output.
- The result contract in PRD.md section 9 is the single source of truth. `schemas.py` and `types.ts` must match it.
- Policies, thresholds and weights live in config files (`policies.yaml`, `config.py`), not hard-coded in logic.
- Small files, one responsibility. One detector per file. One agent step per file.
- No secrets in code. Read from environment variables.

## Error handling
- Every external call (TigerGraph, LLM) has a timeout and returns a typed error, never a raw stack trace to the UI.
- If evidence is missing (for example no identity record for a card-present transaction), record it as `missing`, raise uncertainty, and continue. Do not crash and do not guess.
- If the LLM fails, return the result with a template rationale built from the evidence. The decision must not depend on the LLM being up.
- The UI shows a clear empty, loading and error state for every panel.

## Frontend rules
- Follow Design.md exactly: colours, fonts, motion, the intro sequence and the neon text effect.
- Respect `prefers-reduced-motion`: skip the intro, show text and states without animation.
- The intro must always be skippable (button and Escape).
- All animated text keeps an accessible label (the real text) with the animated glyphs hidden from screen readers.
- Keep GPU load low: no dozens of simultaneous blur filters, no huge particle systems.

## Workflow rules
- Work on one phase at a time (Phases.md). Do not start the next phase early.
- Before coding, read `Memory.md`. After finishing a task, update `Memory.md`.
- Do not re-read the whole codebase. Use the file map in `Memory.md`.
- Run the tests for the area you changed before saying it is done.
- If something in the docs is unclear or contradicts the dataset README, stop and ask.
