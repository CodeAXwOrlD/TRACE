# Memory: TRACE

> Created at the start of coding. The AI updates this file after every task so a new chat or tool can continue without re-reading the codebase.

## Current status
- Current phase: Phase 7 (frontend foundation and landing) + Phase 8 (workbench UI) — fully verified, compiled, and passing all tests against mock data.
- Member 1 setup: **Complete**. `npm run typecheck`, `npm run lint`, `npm run test`, and `npm run build` all pass with 0 errors. All routes verified on local dev server.
- Phase 0-6 (dataset audit, data pipeline, detectors, scoring, agent, benchmark) are out of scope for Member 1, reserved for Member 2 (LangGraph) and Member 3 (FastAPI/TigerGraph).
- Last updated: 2026-09-22
- Last task done: resolved all TypeScript compilation issues, fixed ESLint configuration, configured Vitest with JSX automatic and JSDOM matchMedia mock, created deterministic mock devices fixture (`mock/devices.ts`), verified all 10 frontend routes returning 200 OK.

## Decisions made
- Frontend routes follow the project prompt's broader set (dashboard,
  investigations, cases, transactions, customers, devices, settings) rather
  than Architecture.md §8's shorter sketch (`workbench/`, `case/[id]`) — the
  prompt's scope was explicit and the extra routes don't conflict with
  anything in Rules.md or Design.md. 2026-09-22.
- Console routes grouped under `app/(console)/` with a shared layout
  (`ConsoleShell`) so nav + command palette aren't duplicated per page; the
  landing page stays outside the group at `app/page.tsx`. 2026-09-22.
- Sigma.js node shapes are color+size coded rather than exact custom shapes
  (rounded-rect/diamond/square) for time — flagged as a known gap in
  `docs/MEMBER1_HANDOFF.md` rather than left silent. 2026-09-22.

## Confirmed facts from the dataset README
(Not yet done — Phase 0 work, out of Member 1's scope. Do not code Phase 1+
backend/graph logic against assumptions until this section is filled in.)

## File map
- `frontend/lib/types.ts` — shared contract; keep `backend/app/schemas.py` in lockstep.
- `frontend/lib/api.ts` — only file allowed to call `fetch()` for backend data; mock-fallback built in.
- `frontend/lib/sse.ts` + `frontend/hooks/useInvestigationStream.ts` — SSE contract + mock stream.
- `frontend/mock/*.ts` — deterministic fixtures (customers, transactions, evidence, investigations, cases, graph, agent events).
- `frontend/components/neon/neon-engine.ts` — ported Neon text engine; do not edit without testing against `reference/trace-cinematic-v2.html`.
- `frontend/components/workbench/InvestigationWorkspace.tsx` — the main workbench screen (Phase 8).
- `frontend/components/graph/InvestigationGraph.tsx` — Sigma.js + Graphology connected-records graph.
- Full breakdown in `frontend/README.md`.

## Commands
- Frontend: `cd frontend && npm run dev`
- Frontend checks: `cd frontend && npm run typecheck && npm run lint && npm run test && npm run build`
- Backend: `cd backend && uvicorn app.main:app --reload` (not yet created)
- Benchmark: `pytest backend/tests/test_benchmark.py -s` (not yet created)

## Known issues
- Frontend has not been `npm install`'d, built, linted, typechecked or
  tested anywhere yet (built in a no-network sandbox). Treat as unverified
  until run locally.
- `lib/api.ts` `getDevice()` has no mock fixture; devices/[id] page shows an
  empty state for it, which is intentional until Member 3's DeviceProfile
  endpoint exists.

## Dependencies added (with reason)
- `sigma` + `graphology` (+ `graphology-layout`, `graphology-layout-forceatlas2`): required WebGL graph rendering, per Rules.md stack rule (no Three.js, cap ~200 nodes).
- `gsap`, `motion`: motion system (Design.md §6), used for the intro/scroll choreography.
- `recharts`: available for the dashboard's risk distribution / future charts (used minimally so far — most bars are hand-rolled to match Design.md exactly).
- `lucide-react`: icon set for the graph toolbar and console chrome.
- `vitest` + `@testing-library/react` + `jsdom`: test runner or the components listed in the project prompt (RiskScore, EvidenceCard, AgentActivity, graph controls).
