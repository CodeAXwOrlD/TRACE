# TRACE project docs

Feed these to the AI coding tool in this order at the start of every new chat:

1. `Memory.md` (what is done, what is next). Read this first.
2. `Rules.md` (hard boundaries)
3. `Phases.md` (find the current phase, do only that phase)
4. `PRD.md`, `Architecture.md`, `Design.md` (only when the phase needs them)

`reference/` holds the two approved HTML design previews:
- `trace-design-preview.html`: the analyst workbench layout (case queue, evidence chain, graph, timeline)
- `trace-cinematic-v2.html`: the landing page with the movie intro/outro and the neon border-light text

Anything marked **VERIFY** must be checked against the dataset's own `README.md` before it is built on.
